<?php
namespace NetCents;

class Merchant {}
