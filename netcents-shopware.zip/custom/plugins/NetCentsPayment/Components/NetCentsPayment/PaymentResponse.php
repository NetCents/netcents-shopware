<?php

namespace NetCentsPayment\Components\NetCentsPayment;

class PaymentResponse
{
    /**
     * @var int
     */
    public $id;

    /**
     * @var string
     */
    public $transactionId;

    /**
     * @var string
     */
    public $status;
}
